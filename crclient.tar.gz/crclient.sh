#!/bin/sh
if [ -z $1 ]
then
	echo -e "usage: $(basename $0) [ option ] \n\n--options \n	-r, --execute and login \n	-s, --setpreferences\n	-q, --logout & exit \n"
	exit 0
else
	if   [ $1 = "-r" ]
		then ./CClient/crclient -u subhankar_ece79_2010 -i wlan0 -f CClient/CyberClient.conf
	elif [ $1 = "-s" ]
		then ./CClient/crclient -s
	elif [ $1 = "-q" ]
		then ./CClient/crclient -l subhankar_ece79_2010 && pkill -KILL crclient
	else
		echo -e "usage: $(basename $0) [ option ] \n\n--options \n	-r, --execute and login \n	-s, --setpreferences\n	-q, --logout & exit \n"
	exit 0
	fi
fi

